<table style="border: 1px solid #000; width:600px; "> 
	<tr>
		<th colspan="4"> Notification is Successfully Added </th>
	</tr>
	<tr>
		<th> Full Name </th>
		<th> User ID </th>
		<th> Display URL </th>
		<th> Description </th>
	</tr>
	<tr>
		<td>{{$details['full_name']}} </td>
		<td>{{$details['user_id']}} </td>
		<td>{{$details['display_url']}} </td>
		<td>{{$details['description']}} </td>
	</tr>
</table>